//
//  Pet.swift
//  Miawouf
//
//  Created by Lauriane Haydari on 07/08/2019.
//  Copyright © 2019 Lauriane Haydari. All rights reserved.
//

import Foundation

struct Pet {
    var name: String?
    var hasMajority: Bool
    var race: String?
    var gender: Gender

    init(name: String?, hasMajority: Bool, race: String?, gender: Gender) {
        self.name = name
        self.hasMajority = hasMajority
        self.race = race
        self.gender = gender
    }

    enum Gender {
        case male, female
    }
}
