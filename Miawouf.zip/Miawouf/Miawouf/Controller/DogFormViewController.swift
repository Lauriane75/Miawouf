//
//  FormViewController.swift
//  Miawouf
//
//  Created by Lauriane Haydari on 06/08/2019.
//  Copyright © 2019 Lauriane Haydari. All rights reserved.
//

import UIKit

class DogFormViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate {

    var dog: Pet!

    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var majorirySwitch: UISwitch!
    @IBOutlet weak var genderSegmentedControler: UISegmentedControl!
    @IBOutlet weak var racePickerView: UIPickerView!

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return dogRaces.count
    }

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return dogRaces[row]
    }

    // works with protocol UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    @IBAction func dismissKeybord(_ sender: UITapGestureRecognizer) {
        nameTextField.resignFirstResponder()
    }

    @IBAction func validate() {
        createPetObject()
    }

    private func createPetObject() {
        let name = nameTextField.text
        let hasMajoriry = majorirySwitch.isOn
        let genderIndex = genderSegmentedControler.selectedSegmentIndex
        let gender : Pet.Gender = (genderIndex == 0) ? .female : .male
        let raceIndex = racePickerView.selectedRow(inComponent: 0)
        let race = dogRaces[raceIndex]
        let dog = Pet(name: name, hasMajority: hasMajoriry, race: race, gender: gender)
        print ("dog : \(dog)")

        }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "dogSegueToSuccess" {
            let success = segue.destination as! DogSuccessViewController
            success.dog = dog
        }
    }

} // end
