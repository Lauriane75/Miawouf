//
//  SuccessViewController.swift
//  Miawouf
//
//  Created by Lauriane Haydari on 06/08/2019.
//  Copyright © 2019 Lauriane Haydari. All rights reserved.
//

import UIKit

class DogSuccessViewController: UIViewController {

    var dog: Pet!

    @IBAction func dismiss(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }

}
