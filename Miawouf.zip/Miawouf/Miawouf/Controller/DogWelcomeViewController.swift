//
//  WelcomeViewController.swift
//  Miawouf
//
//  Created by Lauriane Haydari on 06/08/2019.
//  Copyright © 2019 Lauriane Haydari. All rights reserved.
//

import UIKit

class DogWelcomeViewController: UIViewController {
    @IBAction func unwindToWelcome(for unwindSegue: UIStoryboardSegue, towards subsequentVC: UIViewController) {
    
    }


}
